
float foo (float pf) {
  return pf+1;
}